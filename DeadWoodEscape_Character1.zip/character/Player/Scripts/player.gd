class_name Player extends CharacterBody2D

# Set the cardinal directions
var cardinal_direction: Vector2 = Vector2.DOWN
# An array of all vector2 directions you can go (used for strafing)
const DIR_4 = [Vector2.RIGHT, Vector2.DOWN, Vector2.LEFT, Vector2.UP]
var direction: Vector2 = Vector2.ZERO

# Import the animation player and character design, as well as the 
# state machine

@onready var animation_player: AnimationPlayer = $AnimationPlayer
@onready var effect_animation_player: AnimationPlayer = $EffectAnimationPlayer
@onready var sprite: Sprite2D = $Sprite2D
@onready var state_machine: PlayerStateMachine = $StateMachine
@onready var hit_box: HitBox = $HitBox

# Signal when you change direction
signal DirectionChanged(new_direction: Vector2)

# Signal when player takes damage
signal player_damaged(hurt_box: HurtBox)

# Certain effects
var invulnerable: bool = false

# Player health
var hp: int = 6
var max_hp: int = 6

# Initialize the state machine
func _ready():
	print("PLAYER CREATED:", get_instance_id())
	PlayerManager.player = self
	state_machine.initialize(self)
	hit_box.damaged.connect(_take_damage)
	update_hp(99)
	pass

# Handle which direction the player is moving
func _process(delta):
	direction.x = Input.get_action_strength("right") - Input.get_action_strength("left")
	direction.y = Input.get_action_strength("down") - Input.get_action_strength("up")
	
	pass
	
func _physics_process(delta):
	move_and_slide()
	
# Function to set the direction of the character
func SetDirection() -> bool:
	if direction == Vector2.ZERO:
		return true
	
	# Relates every direction to one of the Vectors in the array
	var direction_id: int = int(round((direction + cardinal_direction * 0.1).angle() / TAU * DIR_4.size()))
	var new_dir = DIR_4[direction_id]
		
	if new_dir == cardinal_direction:
		return true	
		
	cardinal_direction = new_dir
	DirectionChanged.emit(new_dir)
	sprite.scale.x = -1 if cardinal_direction == Vector2.LEFT else 1 
	return true
	
# Set the animation to the correct animation
func UpdateAnimation(state: String) -> void:
	animation_player.play(state + "_" + AnimDirection())
	pass
	
# The correct walking animation 
# (for example if the character is going down set to down walking
# otherwise set to side walk)
func AnimDirection() -> String:
	if cardinal_direction == Vector2.DOWN:
		return "down"
	elif cardinal_direction == Vector2.UP:
		return "up"
	else:
		return "side"
	
func _take_damage(hurt_box: HurtBox) -> void:
	# Return if the player is invulnerable
	if invulnerable == true:
		return
	update_hp( -hurt_box.damage)
	if hp > 0:
		player_damaged.emit(hurt_box)
	else:
		# Future updates will add in a death animation
		# but for now update health back to full
		player_damaged.emit(hurt_box)
		update_hp(99)
		
	pass
	
	# Separated from player because it could be used for
	# player healing in future 
func update_hp(delta: int) -> void:
	# Have it between 0 and max hp at all times
	# clampi clamps the value to an integer
	hp = clampi(hp + delta, 0, max_hp)
	PlayerHud.update_hp(hp, max_hp)
	pass
	
func make_invulnerable(_duration: float = 1.0) -> void:
	invulnerable = true
	hit_box.monitoring = false
	
	# Create a timer for how long to be invulnerable
	await get_tree().create_timer(_duration).timeout
	
	# Set invulnerable back to false
	invulnerable = false
	hit_box.monitoring = true
	pass
