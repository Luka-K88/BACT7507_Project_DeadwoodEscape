class_name State_attack extends State

# Set attacking to false by default
var attacking: bool = false

# Import the sound effects and other player
@export var attack_sound: AudioStream
@export_range(1,20,0.5) var decelerate_speed: float = 5.0
@onready var audio: AudioStreamPlayer2D = $"../../Audio/AudioStreamPlayer2D"
@onready var animation_player: AnimationPlayer = $"../../AnimationPlayer"
@onready var attack_animation: AnimationPlayer = $"../../Sprite2D/AttackEffectSprite/AnimationPlayer"
@onready var walk: State = $"../Walk"
@onready var idle: State = $"../Idle"
@onready var hurt_box : HurtBox = %AttackHurtBox

# When player enters attack state then update to play attack animation
func Enter() -> void:
	player.UpdateAnimation("attack")
	attack_animation.play("attack_" + player.AnimDirection())
	animation_player.animation_finished.connect(EndAttack)
	
	# Play sound effect
	audio.stream = attack_sound
	# Pitch the sound randomly 
	audio.pitch_scale = randf_range(0.9, 1.1)
	audio.play()
	attacking = true
	
	# Make the hurtbox wait for the animation
	await get_tree().create_timer(0.075).timeout
	# Set hurtbox to turn on monitoring
	hurt_box.monitoring = true
	pass 
	
# End attack, exit state and set attacking back to false.
func Exit() -> void:
	animation_player.animation_finished.disconnect(EndAttack)
	attacking = false
	
	# Set hurtbox monitoring back to false
	hurt_box.monitoring = false
	pass
	
# Adjust speed when attacking
func Process(_delta: float) -> State:
	player.velocity -= player.velocity * decelerate_speed * _delta 
	
	# Return the player to idle or walk once its done attacking
	if attacking == false:
		if player.direction == Vector2.ZERO:
			return idle
		else:
			return walk
	return null
	
# Return physics and input as null (these are done in state machine)
func Physics(_delta: float) -> State:
	return null
	
func HandleInput(_event: InputEvent ) -> State:
	return null

# End attack
func EndAttack(_newAnimName: String) -> void:
	attacking = false
