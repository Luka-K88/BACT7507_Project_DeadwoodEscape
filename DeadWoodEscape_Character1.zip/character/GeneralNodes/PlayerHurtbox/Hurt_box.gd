class_name HurtBox extends Area2D

# Export damage
@export var damage: int = 10

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	area_entered.connect(AreaEntered)
	pass


func _process(delta: float) -> void:
	pass

# When this function gets a signal from area_entered
# if its a hitbox, do damage to whatever it entered
func AreaEntered(a: Area2D) -> void:
	if a is HitBox:
		a.TakeDamage(damage)
