class_name HitBox extends Area2D

# Send a signal when damage is done
signal damaged(damage: int)

func _ready() -> void:
	pass 


func _process(delta: float) -> void:
	pass

# Debugging print statement for redundancy
func TakeDamage(damage: int) -> void:
	print("Damage Taken: ", damage)
	damaged.emit(damage)
	
	
	
