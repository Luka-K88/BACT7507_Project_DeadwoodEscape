extends Node

# Preload the player scene
const PLAYER = preload("uid://b4u88j2f1elmc")

var player: Player
var player_spawned: bool = false

func _ready() -> void:
	add_player_instance() 

func add_player_instance() -> void:
	# Create a player, and assign it to this variable
	player = PLAYER.instantiate()
	add_child(player)
	pass
	
# A function to set where the player spawns
func set_player_position(_new_pos: Vector2) -> void:
	player.global_position = _new_pos
	pass
	
func set_as_parent(_p: Node2D) -> void:
	# Check if the player has parent, and if it does then
	# remove it 
	if player.get_parent():
		player.get_parent().remove_child(player)
	_p.add_child(player)
	
	# If the player has a child remove it
func unparent_player(_p: Node2D) -> void:
	_p.remove_child(player)
