
extends Camera2D

@export var map_path: NodePath = ^"../Map"
@export_range(0.1, 1.0, 0.05) var margin: float = 0.9

func _ready() -> void:
	enabled = true
	make_current()
	await get_tree().process_frame
	setup_map_camera()


func setup_map_camera() -> void:
	var map_node := get_node_or_null(map_path) as Node2D

	if map_node == null:
		push_warning("Map node not found.")
		return

	var found_tiles := false
	var map_bounds := Rect2()

	for layer in map_node.get_children():
		if layer is TileMapLayer:
			var tile_layer := layer as TileMapLayer

			if tile_layer.tile_set == null:
				continue

			var used := tile_layer.get_used_rect()

			if used.size == Vector2i.ZERO:
				continue

			var tile_size := tile_layer.tile_set.tile_size

			var start_pos := tile_layer.to_global(
				Vector2(used.position * tile_size)
			)

			var end_pos := tile_layer.to_global(
				Vector2(used.end * tile_size)
			)

			var bounds := Rect2(
				start_pos,
				end_pos - start_pos
			).abs()

			if not found_tiles:
				map_bounds = bounds
				found_tiles = true
			else:
				map_bounds = map_bounds.merge(bounds)

	if not found_tiles:
		push_warning("No painted map tiles found.")
		return

	global_position = map_bounds.get_center()

	var viewport_size := get_viewport_rect().size

	if map_bounds.size.x <= 0 or map_bounds.size.y <= 0:
		return

	var zoom_x := viewport_size.x / map_bounds.size.x
	var zoom_y := viewport_size.y / map_bounds.size.y

	var camera_zoom := minf(zoom_x, zoom_y) * margin
	zoom = Vector2.ONE * camera_zoom

	print("Map camera ready")
	print("Map centre: ", global_position)
	print("Map zoom: ", zoom)

	make_current()
