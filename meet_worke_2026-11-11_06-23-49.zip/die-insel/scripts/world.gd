
extends Node2D

var changing_scene: bool = false

func _ready() -> void:
	var player_node: Node2D = get_node_or_null("player") as Node2D

	if player_node == null:
		print("World map loaded successfully. No player found.")
		return

	if global.game_first_loading:
		player_node.position = Vector2(
			global.player_start_posx,
			global.player_start_posy
		)
	else:
		player_node.position = Vector2(
			global.player_exit_map_posx,
			global.player_exit_map_posy
		)

	print("World scene loaded successfully.")

func _process(_delta: float) -> void:
	change_scene()

func _on_camp_exit_body_entered(body: Node2D) -> void:
	if body.has_method("player"):
		global.transition_scene = true

func change_scene() -> void:
	if changing_scene:
		return

	if not global.transition_scene:
		return

	if global.current_scene != "world":
		return

	changing_scene = true

	global.game_first_loading = false
	global.finish_changescenes()

	var error: Error = get_tree().change_scene_to_file(
		"res://scenes/camp.tscn"
	)

	if error != OK:
		push_error("Failed to load camp scene.")
		changing_scene = false
