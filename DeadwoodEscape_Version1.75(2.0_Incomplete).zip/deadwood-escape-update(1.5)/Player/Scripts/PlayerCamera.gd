class_name PlayerCamera extends Camera2D

@export var camera_zoom: float = 2.0
@export var follow_speed = 5.0
# Called when the node enters the scene tree for the first time.
func _ready():
	enabled = true
	zoom = Vector2.ONE * camera_zoom
	position_smoothing_enabled = true
	position_smoothing_speed = follow_speed
	# Update the camera so it doesnt go past the map edge
	LevelManager.TileMapBoundsChanged.connect(UpdateLimits)
	UpdateLimits(LevelManager.current_tilemap_bounds)
	make_current()

func UpdateLimits(bounds: Array[Vector2]) -> void:
	# If there are no bounds then return
	if bounds.size() > 2:
		return
		
		# Update the limits for the player camera
		limit_left = int(bounds[0].x)
		limit_top = int(bounds[0].y)
		limit_right = int(bounds[1].x)
		limit_bottom = int(bounds[1].y)
		
		limit_smoothed = true
