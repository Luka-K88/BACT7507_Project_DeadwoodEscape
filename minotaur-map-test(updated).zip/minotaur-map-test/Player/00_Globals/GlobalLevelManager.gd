extends Node

# A variable containing an array of Vector2s (x and y values)
var current_tilemap_bounds: Array[Vector2]

# Send a signal if map bounds change
signal TileMapBoundsChanged(bounds: Array[Vector2])

func ChangeTilemapBounds(bounds: Array[Vector2]) -> void:
	current_tilemap_bounds = bounds
	
	# Sends the signal for the current map bounds
	TileMapBoundsChanged.emit(bounds)
