class_name PlayerCamera extends Camera2D


# Called when the node enters the scene tree for the first time.
func _ready():
	# Update the camera so it doesnt go past the map edge
	LevelManager.TileMapBoundsChanged.connect(UpdateLimits)
	UpdateLimits(LevelManager.current_tilemap_bounds)
	pass 	

func UpdateLimits(bounds: Array[Vector2]) -> void:
	# If there are no bounds then return
	if bounds == []:
		return
		
	# Update the limits for the player camera
	limit_left = int(bounds[0].x)
	limit_top = int(bounds[0].y)
	limit_right = int(bounds[1].x)
	limit_bottom = int(bounds[1].y)
	pass
