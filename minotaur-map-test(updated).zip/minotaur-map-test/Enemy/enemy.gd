extends CharacterBody2D

enum EnemyState {
	IDLE,
	CHASE,
	RETURN,
	ATTACK,
	DEAD
}

@export_category("Stats")
@export var speed: int = 60
@export var attack_damage: int = 10
@export var attack_speed: float = 1.0
@export var hitpoints: int = 180

@export var aggro_range: float = 256.0
@export var disengage_range: float = 340.0
@export var attack_range: float = 55.0
@export var attack_exit_range: float = 70.0

@export_category("Related Scenes")
@export var death_packed: PackedScene

var state: EnemyState = EnemyState.IDLE
var can_attack: bool = true

@export var repath_interval: float = 0.15
var repath_timer: float = 0.0

@onready var spawn_point: Vector2 = global_position
@onready var animation_tree: AnimationTree = $AnimationTree
@onready var animation_playback: AnimationNodeStateMachinePlayback = $AnimationTree["parameters/playback"]
@onready var sprite: Sprite2D = $Sprite2D
@onready var nav_agent: NavigationAgent2D = $NavigationAgent2D
@onready var hitbox: Area2D = $HITBOX
@onready var hurtbox: Area2D = $HURTBOX

var player: CharacterBody2D = null


func _ready() -> void:
	animation_tree.active = true
	player = get_tree().get_first_node_in_group("player")
	# Friend's hero system: HURTBOX is a HitBox that emits damaged(amount)
	if hurtbox and hurtbox.has_signal("damaged"):
		hurtbox.damaged.connect(_on_hurtbox_damaged)

	await get_tree().physics_frame
	nav_agent.path_desired_distance = 10.0
	nav_agent.target_desired_distance = 12.0

func _process(_delta):
	if player == null:
		player = get_tree().get_first_node_in_group("player")

func _physics_process(delta: float) -> void:
	if state == EnemyState.DEAD:
		return

	if player == null or not is_instance_valid(player):
		player = get_tree().get_first_node_in_group("player")
		return

	repath_timer = max(repath_timer - delta, 0.0)
	update_state()
	move()
	update_animation()

	if state == EnemyState.ATTACK and can_attack:
		attack()


func distance_to_player() -> float:
	return global_position.distance_to(player.global_position)


func can_move_directly(target: Vector2) -> bool:
	var direction := global_position.direction_to(target)
	var distance := global_position.distance_to(target)
	var collision := move_and_collide(direction * min(distance, 24.0), true)
	return collision == null


func update_state() -> void:
	var player_distance := distance_to_player()
	var spawn_distance := global_position.distance_to(spawn_point)

	match state:
		EnemyState.IDLE:
			if player_distance <= aggro_range:
				state = EnemyState.CHASE
		EnemyState.CHASE:
			if player_distance <= attack_range:
				state = EnemyState.ATTACK
			elif player_distance > disengage_range:
				state = EnemyState.RETURN
		EnemyState.ATTACK:
			if player_distance > disengage_range:
				state = EnemyState.RETURN
			elif player_distance > attack_exit_range:
				state = EnemyState.CHASE
		EnemyState.RETURN:
			if player_distance <= aggro_range:
				state = EnemyState.CHASE
			elif spawn_distance <= 18.0:
				state = EnemyState.IDLE


func move() -> void:
	match state:
		EnemyState.CHASE:
			if distance_to_player() <= attack_range:
				velocity = Vector2.ZERO
			else:
				if repath_timer <= 0.0:
					nav_agent.target_position = player.global_position
					repath_timer = repath_interval

				var direct_direction := global_position.direction_to(player.global_position)

				if nav_agent.is_target_reachable() and not nav_agent.is_navigation_finished():
					var next_pos := nav_agent.get_next_path_position()
					var direction := global_position.direction_to(next_pos)
					velocity = direction * speed
				elif can_move_directly(player.global_position):
					velocity = direct_direction * speed
				else:
					velocity = Vector2.ZERO

		EnemyState.RETURN:
			var distance_to_spawn := global_position.distance_to(spawn_point)
			if distance_to_spawn <= 18.0:
				velocity = Vector2.ZERO
			else:
				if nav_agent.target_position != spawn_point:
					nav_agent.target_position = spawn_point
				if nav_agent.is_navigation_finished():
					velocity = Vector2.ZERO
				else:
					var next_pos := nav_agent.get_next_path_position()
					var direction := global_position.direction_to(next_pos)
					velocity = direction * speed

		EnemyState.IDLE, EnemyState.ATTACK:
			velocity = Vector2.ZERO

	move_and_slide()

	if velocity.x < -0.1:
		sprite.flip_h = true
	elif velocity.x > 0.1:
		sprite.flip_h = false


func update_animation() -> void:
	match state:
		EnemyState.IDLE:
			animation_playback.travel("idle")
		EnemyState.CHASE, EnemyState.RETURN:
			animation_playback.travel("run")
		EnemyState.ATTACK:
			animation_playback.travel("attack")


func attack() -> void:
	can_attack = false
	animation_playback.start("attack", true)
	await get_tree().create_timer(attack_speed).timeout
	can_attack = true


func attack_hitbox_on() -> void:
	hitbox.set_deferred("monitoring", true)


func attack_hitbox_off() -> void:
	hitbox.set_deferred("monitoring", false)


func _on_hitbox_area_entered(area: Area2D) -> void:
	# Friend's system: HitBox has TakeDamage(amount)
	if area.has_method("TakeDamage"):
		area.TakeDamage(attack_damage)
		return
	# Fallback: parent has take_damage(amount)
	var target = area.get_parent()
	if target and target.has_method("take_damage"):
		target.take_damage(attack_damage)
	elif target and target.has_method("TakeDamage"):
		target.TakeDamage(attack_damage)


func _on_hurtbox_damaged(amount: int) -> void:
	take_damage(amount)


# Friend's HurtBox calls this on HitBox areas
func TakeDamage(amount: int) -> void:
	take_damage(amount)


func take_damage(damage_taken: int) -> void:
	damageFlash()
	hitpoints -= damage_taken
	if hitpoints <= 0:
		death()


func death() -> void:
	state = EnemyState.DEAD
	if death_packed:
		var death_scene: Node2D = death_packed.instantiate()
		death_scene.position = global_position + Vector2(0.0, -32.0)
		var effects = get_tree().current_scene.get_node_or_null("Effects")
		if effects:
			effects.add_child(death_scene)
		else:
			get_tree().current_scene.add_child(death_scene)
	queue_free()
	
# Simple damage flash to red to show
# damage has been done
func damageFlash() -> void:
	sprite.modulate = Color.RED
	await get_tree().create_timer(0.5).timeout
	sprite.modulate = Color.WHITE
