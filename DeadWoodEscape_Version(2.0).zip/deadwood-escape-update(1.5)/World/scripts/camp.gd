
extends Node2D

var changing_scene: bool = false

func _ready() -> void:
	print("Camp scene loaded successfully.")

func _process(_delta: float) -> void:
	change_scenes()

func _on_world_exit_body_entered(body: Node2D) -> void:
	if body.has_method("player"):
		Global.transition_scene = true

func change_scenes() -> void:
	if changing_scene:
		return

	if not Global.transition_scene:
		return

	if Global.current_scene != "camp":
		return

	changing_scene = true

	Global.finish_changescenes()

	var error: Error = get_tree().change_scene_to_file(
		"res://scenes/world.tscn"
	)

	if error != OK:
		push_error("Failed to load world scene.")
		changing_scene = false
