
extends Node2D

var changing_scene: bool = false

func _ready() -> void:
	update_map_bounds()
	var player_node: Node2D = get_node_or_null("player") as Node2D

	if player_node == null:
		print("World map loaded successfully. No player found.")
		return

	if Global.game_first_loading:
		player_node.position = Vector2(
			Global.player_start_posx,
			Global.player_start_posy
		)
	else:
		player_node.position = Vector2(
			Global.player_exit_map_posx,
			Global.player_exit_map_posy
		)

	print("World scene loaded successfully.")

func _process(_delta: float) -> void:
	change_scene()

func _on_camp_exit_body_entered(body: Node2D) -> void:
	if body.has_method("player"):
		Global.transition_scene = true

func change_scene() -> void:
	if changing_scene:
		return

	if not Global.transition_scene:
		return

	if Global.current_scene != "world":
		return

	changing_scene = true

	Global.game_first_loading = false
	Global.finish_changescenes()

	var error: Error = get_tree().change_scene_to_file(
		"res://scenes/camp.tscn"
	)

	if error != OK:
		push_error("Failed to load camp scene.")
		changing_scene = false
		
func update_map_bounds() -> void:
	var map_node := get_node_or_null("Map") as Node2D
	
	if map_node == null:
		push_warning("Map Node not Found")
		return
		
	var bounds := Rect2()
	var found := false
	
	for child in map_node.get_children():
		if child is TileMapLayer:
			var layer := child as TileMapLayer
			
			if layer.tile_set == null:
				continue
				
				var used := layer.get_used_rect()
				
				if used.size == Vector2i.ZERO:
					continue
					
				var tile_size := layer.tile_set.tile_size
				
				var top_left := layer.to_global(
					Vector2(used.position * tile_size)
				)
				
				var bottom_right := layer.to_global(
					Vector2(used.end * tile_size)
				)
				
				var layer_bounds := Rect2(
					top_left,bottom_right - top_left
				).abs()
				
				if not found:
					bounds = layer_bounds
					found = true
				else:
					bounds = bounds.merge(layer_bounds)
					
			if not found:
				push_warning("No Painted Map Tiles Found")
				return
			
			var map_limits: Array[Vector2] = [
				bounds.position,
				bounds.end
			]
			
			LevelManager.ChangeTilemapBounds(map_limits)
