# Minotaur + Test Map (compatible with your hero)

Contains **only**:
- The test map (`world.tscn`)
- The minotaur enemy + death animation
- A tiny `Compat/HitBox.gd` so your HitBox/HurtBox combat system can damage the minotaur

No player/hero is included — use yours.

## How to use with your hero

1. Copy these folders into your Godot 4.3+ project (or open this folder and add your hero):
   - `Enemy/`
   - `Assets/`
   - `Compat/`
   - `world.tscn` (optional — or instance the enemy into your own level)

2. Open `world.tscn` (or your level) and **instance your hero**.

3. On your hero, make sure:
   - It is in the **`"player"`** group (required for aggro)
   - Its damage-receiving area is a **`HitBox`** (class_name HitBox) on **collision layer 2** (`PlayerHurt`)
   - Its attack area is a **`HurtBox`** that masks **layer 9 / bit 256** (same as your current setup)

4. Play. The minotaur will chase and attack you; your attacks should damage it.

## Collision setup (already matched to your project)

| What | Layer / mask |
|------|----------------|
| Your HitBox (takes damage) | layer **2** |
| Your attack HurtBox | mask **256** |
| Minotaur HURTBOX (takes damage) | layer **256** + `HitBox` script |
| Minotaur HITBOX (deals damage) | mask **2** → calls `TakeDamage` on HitBoxes |

## If something doesn’t connect

- Aggro fails → hero not in group `"player"`
- You can’t hurt the minotaur → attack HurtBox mask isn’t 256, or target isn’t `HitBox`
- Minotaur can’t hurt you → your HitBox isn’t on layer 2, or doesn’t have `TakeDamage(amount)`

## Credits

Minotaur spritesheet: Stephen Challener (Redshrike) + Bonsaiheldin (CC-BY 3.0)
