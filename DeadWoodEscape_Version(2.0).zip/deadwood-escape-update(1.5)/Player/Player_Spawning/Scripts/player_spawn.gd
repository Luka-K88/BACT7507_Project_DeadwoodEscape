extends Node2D

func _ready() -> void:
	# Set to false so the example spawn isn't visible
	# during gameplay
	visible = false
	if PlayerManager.player_spawned == false:
		PlayerManager.set_player_position(global_position)
		PlayerManager.player_spawned = true
