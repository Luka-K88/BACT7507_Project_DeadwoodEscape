class_name HeartGUI extends Control

@onready var sprite_2d: Sprite2D = $Sprite2D


# Create a variable to set the value of a heart
var heart_value: int = 2: 
	set(_value):
		heart_value = _value
		update_sprite()

# Update the heart sprite
func update_sprite() -> void:
	sprite_2d.frame = heart_value
