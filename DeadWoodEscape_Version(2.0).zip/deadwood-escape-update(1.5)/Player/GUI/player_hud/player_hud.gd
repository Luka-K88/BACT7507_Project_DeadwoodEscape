extends CanvasLayer

# Make the hearts an array of the heart gui objects
# (the heart sprites)
var hearts: Array[HeartGUI] = []


# Put the hearts in the array by using a for statement
# to count the children within the Horizontal Container
# (HFlowContainer)
func _ready() -> void:
	for child in $Control/HFlowContainer.get_children():
		if child is HeartGUI:
			hearts.append(child)
			child.visible = false
	pass

func update_hp (_hp: int, _max_hp: int) -> void:
	update_max_hp(_max_hp)
	
	# Count from 0 to whatever max HP is
	for i in _max_hp:
		update_heart(i, _hp)
		pass
	pass


func update_heart(_index: int, _hp: int) -> void:
	# HP is equal to the HP - the index * 2 because each
	# heart has a value of 2
	var _value: int = clampi(_hp - _index * 2, 0, 2)
	
	# Get the index of the heart
	# (if the index is 0, it will grab first heart,
	# if its 1 it will grab the second heart etc)
	hearts[_index].heart_value = _value
	pass


func update_max_hp(_max_hp: int) -> void:
	# Count the hearts, rounded up
	var _heart_count: int = roundi(_max_hp * 0.5)
	
	# For each heart, if i is less than the number
	# of hearts, it will make it visible
	for i in hearts.size():
		if i < _heart_count:
			hearts[i].visible = true
		else:
			hearts[i].visible = false	
	pass
