class_name State extends Node

# Set a variable for player
static var player: Player
static var state_machine: PlayerStateMachine

# Rest is handled by state machine, this is kept for redundancy
func _ready() -> void:
	pass
	
func init() -> void:
	pass
	
func Enter() -> void:
	pass 
	

func Exit() -> void:
	pass
	
func Process(_delta: float) -> State:
	return null
	
func Physics(_delta: float) -> State:
	return null
	
func HandleInput(_even: InputEvent) -> State:
	return null
