class_name State_idle extends State
	
# Import the other states
@onready var walk: State = $"../Walk"
@onready var attack: State = $"../Attack"

# When player enters state, update animation
func Enter() -> void:
	player.UpdateAnimation("idle")
	pass 
	

func Exit() -> void:
	pass
	
# If the direction is not 0, set to walk, otherwise return nothing
func Process(_delta: float) -> State:
	if player.direction != Vector2.ZERO:
		return walk
	player.velocity = Vector2.ZERO
	return null
	
# Physics is handled by state machine
func Physics(_delta: float) -> State:
	return null
	
# If player attacks, set the state to attack.
func HandleInput(_event: InputEvent ) -> State:
	if _event.is_action_pressed("attack"):
		return attack
	return null
