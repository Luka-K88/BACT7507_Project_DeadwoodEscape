class_name PlayerStateMachine extends Node

# This stores the states, the previous states and the current state of the
# player (for example it could be walking or running).
var states: Array[State]
var prev_state: State
var current_state: State

	# Disable process mode
func _ready() -> void:
	process_mode = Node.PROCESS_MODE_DISABLED
	pass 


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	ChangeState(current_state.Process(delta))
	pass
	
# Handle the physics
func _physics_process(delta: float) -> void:
	ChangeState(current_state.Physics(delta))
	pass
	
# Handle an unhandled input
func _unhandled_input(event):
	ChangeState(current_state.HandleInput(event))
	pass


func initialize(_player: Player) -> void:
# Add all states to a list
	states = []
		
	# Check the state of the player
	for c in get_children():
		if c is State:
			c.player = _player
			states.append(c)
	
	if states.size() == 0:
		return
	
	states[0].player = _player
	states[0].state_machine = self
	
	for state in states:
		state.init()
	
	ChangeState(states[0])
	process_mode = Node.PROCESS_MODE_INHERIT
	
# This is the main part of the state machine
# change states and store the previous and current state.
func ChangeState(new_state: State) -> void:
	if new_state == null || new_state == current_state:
		return
	
	if current_state:
		current_state.Exit()
		
	prev_state = current_state
	current_state = new_state
	current_state.Enter()
