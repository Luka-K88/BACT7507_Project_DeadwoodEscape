class_name PlayerInteractionsHost extends Node2D

@onready var player: Player = $".."

# Update the direction when the player gets the signal
func _ready() -> void:
	player.DirectionChanged.connect(UpdateDirection)
	pass


# Rotate the hit box (the red circle at players feet)
# to the direction they are facing
func UpdateDirection(new_direction: Vector2) -> void:
	match new_direction:
		Vector2.DOWN:
			rotation_degrees = 0
		Vector2.UP:
			rotation_degrees = 180
		Vector2.LEFT:
			rotation_degrees = 90
		Vector2.RIGHT:
			rotation_degrees = -90
		# Set a redundant default as 0 degrees
		_:
			rotation_degrees = 0
	pass
