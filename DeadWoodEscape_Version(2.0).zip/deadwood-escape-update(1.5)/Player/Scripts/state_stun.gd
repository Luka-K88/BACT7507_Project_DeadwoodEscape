class_name State_Stun extends State
	
	# Variables for knockback, decelerate and invulnerability
@export var knockback_speed: float = 200.0
@export var decelerate_speed: float = 10.0
@export var invulnerable_duration: float = 1.0 

var hurt_box: HurtBox
var direction: Vector2

# Handle the next state
var next_state: State = null

# Import idle state, because it will be in idle once
# it isn't stunned anymore
@onready var idle: State = $"../Idle"

func init() -> void:
	player.player_damaged.connect(_player_damaged)

func Enter() -> void:
	player.animation_player.animation_finished.connect(_animation_finished)
	
	# Allow knockback when player is hit
	player.velocity = -player.cardinal_direction * knockback_speed
	player.velocity = direction * -knockback_speed
	player.SetDirection()
	
	player.UpdateAnimation("stun")
	# Make the player invulnerable to stop death loop
	player.make_invulnerable(invulnerable_duration)
	player.effect_animation_player.play("damaged")
	pass 
	

func Exit() -> void:
	next_state = null
	player.animation_player.animation_finished.disconnect(_animation_finished)
	pass
	
func Process(_delta: float) -> State:
	player.velocity -= player.velocity * decelerate_speed * _delta 
	return next_state
		
func Physics(_delta: float) -> State:
	return next_state
	
func HandleInput(_event: InputEvent) -> State:
	return null
	
	
# Allows stun to override other states
func _player_damaged(damage: int) -> void:
	state_machine.ChangeState(self)
	pass
	
func _animation_finished(_a: String) -> void:
	# Set the state after stun to idle
	next_state = idle
	pass
	
