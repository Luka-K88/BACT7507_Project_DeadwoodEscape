class_name PlayerHitBox extends Area2D

# Send a signal when damage is done
signal damaged(damage: int)

func _ready() -> void:
	pass 


func _process(delta: float) -> void:
	pass

# Debugging print statement for redundancy
func TakeDamage(damage: int) -> void:
	if damage <= 0:
		return
	
	
	var player = get_parent() as Player
	if player == null:
		print("Player not found")
		return
		
		if player.invulnerable:
			print("Damage blocked")
			return
			
	print("Player Damage Taken: ", damage)
	damaged.emit(damage)
	
	
	
	
	
