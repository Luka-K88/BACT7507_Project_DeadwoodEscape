class_name EnemyHitBox
extends Area2D
## Minimal compatibility shim so this project works with a hero that uses
## the HitBox / HurtBox pattern (area is HitBox → call TakeDamage).

signal damaged(amount: int)

func TakeDamage(amount: int) -> void:
	print("Enemy Damage taken", amount)
	damaged.emit(amount)
