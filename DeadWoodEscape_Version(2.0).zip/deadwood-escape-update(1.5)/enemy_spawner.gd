extends Node2D

@export var enemy_scene: PackedScene
@export var spawn_interval: float =4.0 #BETWEEN spawns
@export var max_enemies: int = 6 #MAX spawn
@export var spawn_radius: float= 300.0

@onready var enemies_parent: Node2D = get_node_or_null("res://Enemy/ENEMY.tscn")

var timer: float = 0.0

func _ready() -> void:
	if enemies_parent == null:
		enemies_parent = get_tree().current_scene  

func _process(delta: float) -> void:
	timer += delta
	if timer >= spawn_interval:
		timer = 0.0
		try_spawn_enemy()
		
	#COUNTS enemies alive
func try_spawn_enemy() -> void:
	# Count how many enemies are currently alive
	var current_enemies = get_tree().get_nodes_in_group("enemy")
	if current_enemies.size() >= max_enemies:
		return
	
	if enemy_scene == null:
		push_warning("EnemySpawner: No enemy_scene assigned!")
		return
	
	var player = get_tree().get_first_node_in_group("player")
	if player == null:
		return
	
# PICKS random spot near player
	var angle = randf() * TAU
	var offset = Vector2(cos(angle), sin(angle)) * randf_range(spawn_radius * 0.6, spawn_radius)
	var spawn_pos = player.global_position + offset
	
	var enemy = enemy_scene.instantiate()
	enemy.global_position = spawn_pos
	enemies_parent.add_child(enemy)
