extends Node2D


func _ready() -> void:
	$AnimationPlayer.play("death")
	scale = Vector2(0.5, 0.5) #Skull 50% smaller


func _on_animation_player_animation_finished(anim_name: StringName) -> void:
	queue_free()
	
