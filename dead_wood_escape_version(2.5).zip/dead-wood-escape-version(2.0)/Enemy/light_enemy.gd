extends "res://Enemy/enemy.gd"



func _ready() -> void:
	speed = 90
	attack_damage = 1
	hitpoints = 25
	max_hitpoints = 25
	aggro_range = 220.0
	attack_range = 50.0
	
	
	
	super._ready()
