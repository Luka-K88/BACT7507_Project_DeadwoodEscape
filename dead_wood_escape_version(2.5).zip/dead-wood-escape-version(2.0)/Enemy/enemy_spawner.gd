extends Node2D

@export var enemy_scene: PackedScene          # ENEMY.tscn (minotaur)
@export var Light_enemy: PackedScene          # Light_enemy.tscn (slime)

@export var spawn_interval: float = 1
@export var max_enemies: int = 6
@export var spawn_radius: float = 300.0 # STOP FROM SPAWNING OUTSIDE MAP
@export var light_enemy_chance: float = 0.65

# Map bounds spanwer follows that
@export var map_min: Vector2 = Vector2(0,0)
@export var map_max: Vector2 = Vector2(528, 528)

var timer: float = 0.0


func _process(delta: float) -> void:
	timer += delta
	if timer >= spawn_interval:
		timer = 0.0
		try_spawn_enemy()


func try_spawn_enemy() -> void:
	var current_enemies = get_tree().get_nodes_in_group("enemy")
	if current_enemies.size() >= max_enemies:
		return

	var player = get_tree().get_first_node_in_group("player")
	if player == null:
		return

	# PICKS ENEMY TO SPAWN
	var scene_to_spawn: PackedScene = null

	if Light_enemy and randf() < light_enemy_chance:
		scene_to_spawn = Light_enemy
	elif enemy_scene:
		scene_to_spawn = enemy_scene
	else:
		push_warning("EnemySpawner: No enemy scenes assigned!")
		return

# try to spwn INSIDE MAP
	var spawn_pos: Vector2
	for i in range(10):
		var angle = randf() * TAU
		var offset = Vector2(cos(angle), sin(angle)) * randf_range(spawn_radius * 0.5, spawn_radius)
		spawn_pos = player.global_position + offset
		spawn_pos.x = clampf(spawn_pos.x, map_min.x, map_max.x)
		spawn_pos.y = clampf(spawn_pos.y, map_min.y, map_max.y)
		# Accept if still a reasonable distance from player
		if spawn_pos.distance_to(player.global_position) > 40.0:
			break

	var enemy = scene_to_spawn.instantiate()
	enemy.global_position = spawn_pos
	get_tree().current_scene.add_child(enemy)
